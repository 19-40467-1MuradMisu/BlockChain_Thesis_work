const Market = artifacts.require("Test");

module.exports = function (deployer) {
  deployer.deploy(Market);
};